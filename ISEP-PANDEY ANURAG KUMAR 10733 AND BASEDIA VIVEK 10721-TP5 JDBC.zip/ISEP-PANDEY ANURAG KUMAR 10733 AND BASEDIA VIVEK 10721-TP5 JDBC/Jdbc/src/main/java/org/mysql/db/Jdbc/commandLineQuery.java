package org.mysql.db.Jdbc;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Arrays;


import java.io.BufferedReader;

public class commandLineQuery {

	public static void main(String args[])throws Exception{
		//System.out.println("Your first argument is: "+args);  
		 for(String argument : args){
	            System.out.println(argument);
	        } 
		 
		 String str = Arrays.toString(args);
	      str = str.substring(1, str.length()-1).replace(",", "");
	      System.out.println(str); 
		String inputString = str;
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();

		}
		String url = "jdbc:mysql://localhost/sakila" ;
		String user = "root";
		String pass = "root";
		
		Connection connexion=null;
		
		try {
			 connexion = DriverManager.getConnection(url, user,"");
	
			System.out.println("Database Connected");
			   if(args[0].contains("SELECT")||args[0].contains("Select")||args[0].contains("select")){			
			fetchTable(connexion,inputString);}
			   else {
				   updateTable(connexion,inputString);
			   }		
			
		   }     catch (SQLException e) {
			             e.printStackTrace();
		           }  finally {
			            if (connexion != null) {try {
			                  connexion.close();
	                    } catch (SQLException ignore) {
		                        ignore.printStackTrace();
	                          }
		                        }
		
		
		}
}
	
	public  static void fetchTable( Connection connexion,String query) throws SQLException {
		 Statement statement = connexion.createStatement();
		
		     ResultSet dbresult = statement.executeQuery(query);
		     ResultSetMetaData rsmd = dbresult.getMetaData();
		     int columnsNumber = rsmd.getColumnCount();
		    
		     
	             try {
	            while (dbresult.next()) {
	            	for (int i = 1; i <= columnsNumber; i++) {
	                    if (i > 1) System.out.print(",  ");
	                    String columnValue = dbresult.getString(i);
	                    System.out.print(columnValue + " " + rsmd.getColumnName(i));
	                }
	                System.out.println("");
	                   }
	            dbresult.last();
			     int rowNumber =dbresult.getRow();
	            System.out.println("Total number of row"+ " "+rowNumber);
	              } 
	                 catch (SQLException e) {
	                      e.printStackTrace();
	                   }
			
	       
	}
	
	public  static void updateTable( Connection connexion,String query) throws SQLException {
		 Statement statement = connexion.createStatement();		
		 int rNumber= statement.executeUpdate(query);
		    System.out.println("No of row affected"+ " "+rNumber);   

	}
		
}