package org.mysql.db.Jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {

	private static String url = "jdbc:mysql://localhost/sakila" ;
	private static String user = "root";
	private static String pass = "root";
	

	public static Connection getConnection() throws SQLException {
		Connection connection = DriverManager.getConnection(url, user,
				"");
		System.err.println("The connection is successfully obtained");
		return connection;
	}
}