package org.mysql.db.Jdbc;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Db_query {
	public static void main(String[] args)  throws Exception {
		// TODO Auto-generated method stub
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();

		}
		String url = "jdbc:mysql://localhost/sakila" ;
		String user = "root";
		String pass = "root";
		
		Connection connexion=null;
		
		try {
			 connexion = DriverManager.getConnection(url, user,"");
	
			System.out.println("Database Connected");
			
			fetchTable(connexion);
			
		   }     catch (SQLException e) {
			             e.printStackTrace();
		           }  finally {
			            if (connexion != null)
			                	try {
					                  connexion.close();
				                    } catch (SQLException ignore) {
					                        ignore.printStackTrace();
				                          }
		                        }
		             
	 }
		
	
	public  static void fetchTable( Connection connexion) throws SQLException {
		 Statement statement = connexion.createStatement();
		
		     ResultSet resultlastname = statement.executeQuery("SELECT LAST_NAME  FROM ACTOR");
		     System.out.println(resultlastname);
		   
	             try {
	            while (resultlastname.next()) {
	                System.out.println(resultlastname.getString("LAST_NAME"));
	                   }
	              } 
	                 catch (SQLException e) {
	                      e.printStackTrace();
	                   }
			
	             resultlastname.close();


	}
}
