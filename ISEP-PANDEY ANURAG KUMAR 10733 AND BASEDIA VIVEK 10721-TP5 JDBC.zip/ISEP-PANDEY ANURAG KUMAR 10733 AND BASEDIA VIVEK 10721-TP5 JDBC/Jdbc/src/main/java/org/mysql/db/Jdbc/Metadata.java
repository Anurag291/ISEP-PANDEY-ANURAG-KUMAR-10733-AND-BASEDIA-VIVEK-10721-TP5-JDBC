package org.mysql.db.Jdbc;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class Metadata {
		
	public static void main(String[] args) {
		try {
			printGeneralMetadata.printGenralMetadata();
			getColumnsMetadata.getColumnMetadata(getTablesMetadata.getMetadataTable());
		} catch (SQLException e) {
			System.err
					.println("There was an error retrieving the metadata properties: "
							+ e.getMessage());
		}
		
		
	}
}
